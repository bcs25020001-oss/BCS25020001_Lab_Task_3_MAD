package com.example.bcs25020001_lab_task_3_mad

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
