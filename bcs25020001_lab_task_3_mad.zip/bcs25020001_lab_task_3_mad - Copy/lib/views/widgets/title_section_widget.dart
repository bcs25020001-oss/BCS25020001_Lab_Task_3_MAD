import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/cruise_booking_viewmodel.dart';

class TitleSectionWidget extends StatelessWidget {
  final String name;
  final String location;

  const TitleSectionWidget({super.key, required this.name, required this.location});

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<CruiseBookingViewModel>();

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(location, style: TextStyle(color: Colors.grey[600])),
              ],
            ),
          ),
          InkWell(
            onTap: () => context.read<CruiseBookingViewModel>().incrementRating(),
            child: Row(
              children: [
                const Icon(Icons.star, color: Colors.orange),
                const SizedBox(width: 4),
                Text('${viewModel.rating}', style: const TextStyle(fontSize: 16)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}