import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/cruise_booking_viewmodel.dart';

class BookingControlsWidget extends StatelessWidget {
  const BookingControlsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<CruiseBookingViewModel>();

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Trip Preferences', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Cruise Date:'),
            trailing: Text(
              viewModel.selectedDate == null
                  ? 'Select Date'
                  : '${viewModel.selectedDate!.day}/${viewModel.selectedDate!.month}/${viewModel.selectedDate!.year}',
              style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
            ),
            onTap: () async {
              DateTime? picked = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime.now(),
                lastDate: DateTime(2030),
              );
              if (picked != null) {
                context.read<CruiseBookingViewModel>().setDate(picked);
              }
            },
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Transport Mode:'),
            trailing: DropdownButton<String>(
              value: viewModel.selectedPackage,
              items: viewModel.packageOptions.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (newValue) {
                if (newValue != null) {
                  context.read<CruiseBookingViewModel>().setPackage(newValue);
                }
              },
            ),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Dark Mode'),
            trailing: Switch(
              value: viewModel.isDarkMode,
              onChanged: (value) => context.read<CruiseBookingViewModel>().toggleTheme(value),
            ),
          ),
        ],
      ),
    );
  }
}