import 'package:flutter/material.dart';
import '../../models/cruise_destination.dart';
import 'widgets/header_image_widget.dart';
import 'widgets/title_section_widget.dart';
import 'widgets/action_bar_widget.dart';
import 'widgets/description_widget.dart';
import 'widgets/booking_controls_widget.dart';

class CruiseBookingScreen extends StatelessWidget {
  final CruiseData cruiseData;

  const CruiseBookingScreen({super.key, required this.cruiseData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sibu River Cruise & Heritage'),
        actions: [
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {})
        ],
      ),
      body: OrientationBuilder(
        builder: (context, orientation) {
          if (orientation == Orientation.portrait) {
            return ListView(
              children: [
                HeaderImageWidget(imageUrl: cruiseData.imageUrl),
                TitleSectionWidget(name: cruiseData.name, location: cruiseData.location),
                const ActionBarWidget(),
                DescriptionWidget(description: cruiseData.description),
                const BookingControlsWidget(),
              ],
            );
          } else {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 1,
                  child: HeaderImageWidget(imageUrl: cruiseData.imageUrl),
                ),
                Expanded(
                  flex: 1,
                  child: ListView(
                    children: [
                      TitleSectionWidget(name: cruiseData.name, location: cruiseData.location),
                      const ActionBarWidget(),
                      DescriptionWidget(description: cruiseData.description),
                      const BookingControlsWidget(),
                    ],
                  ),
                ),
              ],
            );
          }
        },
      ),
    );
  }
}