import 'package:flutter/material.dart';

class CruiseBookingViewModel extends ChangeNotifier {
  int _rating = 43;
  DateTime? _selectedDate;
  String _selectedPackage = 'Private River Cruise';
  bool _isDarkMode = false;

  final List<String> packageOptions = [
    'Private River Cruise',
    'Sunset Cruise',
    'Sunrise Cruise',
    'Rural Cruise',
    'SMI Park Cruise'
  ];

  int get rating => _rating;
  DateTime? get selectedDate => _selectedDate;
  String get selectedPackage => _selectedPackage;
  bool get isDarkMode => _isDarkMode;

  void incrementRating() {
    _rating++;
    notifyListeners();
  }

  void setDate(DateTime date) {
    _selectedDate = date;
    notifyListeners();
  }

  void setPackage(String package) {
    _selectedPackage = package;
    notifyListeners();
  }

  void toggleTheme(bool value) {
    _isDarkMode = value;
    notifyListeners();
  }
}