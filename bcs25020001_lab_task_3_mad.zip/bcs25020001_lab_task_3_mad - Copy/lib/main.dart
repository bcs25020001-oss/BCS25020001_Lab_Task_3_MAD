import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/cruise_destination.dart';
import 'viewmodels/cruise_booking_viewmodel.dart';
import 'views/cruise_booking_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => CruiseBookingViewModel(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<CruiseBookingViewModel>().isDarkMode;

    final cruiseData = CruiseData(
      name: 'Rajang River Express Cruise',
      location: 'Sibu Waterfront, Sarawak',
      description: 'Experience the heart of Sibu along Malaysia\'s longest river, the Rajang. Cruise past historic temples, timber hubs, and traditional waterfront settlements while experiencing authentic Sarawakian hospitality.',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvJKkqpSFd9OxTzJHCpwyyEqCSaBeSJaWETraBgTiHwz2BkBUd1lf1URo&s=10',
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Rajang River Cruise',
      theme: isDark ? ThemeData.dark() : ThemeData.light(),
      home: CruiseBookingScreen(cruiseData: cruiseData),
    );
  }
}