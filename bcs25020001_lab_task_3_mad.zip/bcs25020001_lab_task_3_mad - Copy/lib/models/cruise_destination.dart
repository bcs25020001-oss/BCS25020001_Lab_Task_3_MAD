class CruiseData {
  final String name;
  final String location;
  final String description;
  final String imageUrl;

  CruiseData({
    required this.name,
    required this.location,
    required this.description,
    required this.imageUrl,
  });
}